'use strict';

module.exports.upload = (event, context, callback) => {
  var s3 = new AWS.S3();
  var params = JSON.parse(event.body);

  var s3Params = {
    Bucket: 'fileshareproject',
    Key:  params.name,
    ContentType: params.type,
    ACL: 'public-read',
  };

  var uploadURL = s3.getSignedUrl('putObject', s3Params);


 callback(null, {
  statusCode: 200,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials" : true, 
    "Content-Type": "application/json"
  },
  body: JSON.stringify({ uploadURL: uploadURL }),
});


  }
